document.addEventListener("DOMContentLoaded", function () {
    // Handle Signup Form Submission
    document.querySelector(".signup-form").addEventListener("submit", async (event) => {
        event.preventDefault();

        const name = document.querySelector(".signup-form input[name='name']").value;
        const email = document.querySelector(".signup-form input[name='email']").value;
        const password = document.querySelector(".signup-form input[name='password']").value;

        const response = await fetch("/signup", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ name, email, password }),
        });

        const result = await response.json();
        alert(result.message);
    });

    // Handle Login Form Submission
    document.querySelector(".login-form").addEventListener("submit", async (event) => {
        event.preventDefault();

        const email = document.querySelector(".login-form input[name='email']").value;
        const password = document.querySelector(".login-form input[name='password']").value;

        const response = await fetch("/login", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ email, password }),
        });

        const result = await response.json();
        alert(result.message);

        if (response.ok) {
            // Store the token in localStorage
            localStorage.setItem("token", result.token); 

            // Redirect the user to the dashboard or another page
            window.location.href = result.redirectUrl || "website.html"; // Redirect to /dashboard by default if no URL is provided
        }
    });
});
